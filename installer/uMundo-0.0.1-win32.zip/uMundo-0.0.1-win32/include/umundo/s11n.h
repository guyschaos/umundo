#ifndef S11N_H_W8QI0KWV
#define S11N_H_W8QI0KWV

#include "umundo/s11n/TypedPublisher.h"
#include "umundo/s11n/TypedSubscriber.h"

#endif /* end of include guard: S11N_H_W8QI0KWV */
