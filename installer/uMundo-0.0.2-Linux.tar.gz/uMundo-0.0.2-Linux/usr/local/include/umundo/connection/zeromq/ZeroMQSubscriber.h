#ifndef ZEROMQSUBSCRIBER_H_6DV3QJUH
#define ZEROMQSUBSCRIBER_H_6DV3QJUH

#include <boost/enable_shared_from_this.hpp>

#include "umundo/common/Common.h"
#include "umundo/common/ResultSet.h"
#include "umundo/connection/Subscriber.h"

namespace umundo {

class PublisherStub;

/**
 * Concrete subscriber implementor for 0MQ (bridge pattern).
 */
class ZeroMQSubscriber : public SubscriberImpl, public ResultSet<PublisherStub>, public boost::enable_shared_from_this<ZeroMQSubscriber> {
public:
	shared_ptr<Implementation> create();
	void destroy();
	void init(shared_ptr<Configuration>);
	virtual ~ZeroMQSubscriber();
	void suspend();
	void resume();

	void added(shared_ptr<PublisherStub>);
	void removed(shared_ptr<PublisherStub>);
	void changed(shared_ptr<PublisherStub>);

	// Thread
	void run();
	void join();

protected:
	ZeroMQSubscriber();
	ZeroMQSubscriber(string, Receiver*);

	set<string> _connections;
	void* _closer; ///< needed to join the thread with blocking receive
	void* _socket;
	void* _zeroMQCtx;
	Mutex _mutex;

private:

	shared_ptr<SubscriberConfig> _config;
	friend class Factory;
};

}

#endif /* end of include guard: ZEROMQSUBSCRIBER_H_6DV3QJUH */
