#ifndef RPC_H_OT9KY60V
#define RPC_H_OT9KY60V

#include "umundo/rpc/Service.h"
#include "umundo/rpc/ServiceManager.h"

#endif /* end of include guard: RPC_H_OT9KY60V */
