/**
 * Auto generated - edit config.h.in instead!
 *
 * This file is instantiated by cmake as config.h in the binary tree of 
 * the out-of-source build. See cmake docs on CONFIGURE_FILE.
 *
 * WARNING: This file may never be included by public headers as we cannot 
 * ship prebuilt packages otherwise!
 */

#ifndef __CONFIG_H
#define __CONFIG_H

/** Platform macros */
/* #undef UNIX */
// suppress warnings with eventual -DWIN32 on compiler invocation
#ifndef WIN32
#define WIN32
#endif
/* #undef APPLE */
/* #undef CYGWIN */
/* #undef IOS */
#ifndef ANDROID
/* #undef ANDROID */
#endif
#define PATH_SEPERATOR '\\'

/** Implementation macros */
#define NET_ZEROMQ
#define S11N_PROTOBUF
#define DISC_BONJOUR
/* #undef DISC_BONJOUR_EMBED */
/* #undef DISC_AVAHI */
#ifndef THREAD_PTHREAD
/* #undef THREAD_PTHREAD */
#endif
#ifndef THREAD_WIN32
#define THREAD_WIN32
#endif

/** Loglevels */
#define LOGLEVEL_COMMON 3
#define LOGLEVEL_DISC 3
#define LOGLEVEL_NET 3
#define LOGLEVEL_S11N 3

/** miscellaneous */
#define PROJECT_SOURCE_DIR "Z:/Documents/TK/Code/umundo"

/** Implementation specific */
#define NET_ZEROMQ_SND_HWM 10000
#define NET_ZEROMQ_RCV_HWM 10000

#endif
