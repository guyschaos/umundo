var NAVTREE =
[
  [ "umundo.core", "index.html", [
    [ "umundo-core", "index.html", null ],
    [ "Related Pages", "pages.html", [
      [ "Todo List", "todo.html", null ]
    ] ],
    [ "Class List", "annotated.html", [
      [ "AvahiNodeDiscovery", "classumundo_1_1_avahi_node_discovery.html", null ],
      [ "AvahiNodeStub", "classumundo_1_1_avahi_node_stub.html", null ],
      [ "BonjourNodeDiscovery", "classumundo_1_1_bonjour_node_discovery.html", null ],
      [ "BonjourNodeStub", "classumundo_1_1_bonjour_node_stub.html", null ],
      [ "Configuration", "classumundo_1_1_configuration.html", null ],
      [ "Debug", "classumundo_1_1_debug.html", null ],
      [ "Discovery", "classumundo_1_1_discovery.html", null ],
      [ "DiscoveryConfig", "classumundo_1_1_discovery_config.html", null ],
      [ "DiscoveryImpl", "classumundo_1_1_discovery_impl.html", null ],
      [ "EndPoint", "classumundo_1_1_end_point.html", null ],
      [ "Factory", "classumundo_1_1_factory.html", null ],
      [ "Implementation", "classumundo_1_1_implementation.html", null ],
      [ "Message", "classumundo_1_1_message.html", null ],
      [ "Monitor", "classumundo_1_1_monitor.html", null ],
      [ "Mutex", "classumundo_1_1_mutex.html", null ],
      [ "Node", "classumundo_1_1_node.html", null ],
      [ "NodeConfig", "classumundo_1_1_node_config.html", null ],
      [ "NodeImpl", "classumundo_1_1_node_impl.html", null ],
      [ "NodeQuery", "classumundo_1_1_node_query.html", null ],
      [ "NodeStub", "classumundo_1_1_node_stub.html", null ],
      [ "Publisher", "classumundo_1_1_publisher.html", null ],
      [ "PublisherConfig", "classumundo_1_1_publisher_config.html", null ],
      [ "PublisherImpl", "classumundo_1_1_publisher_impl.html", null ],
      [ "PublisherStub", "classumundo_1_1_publisher_stub.html", null ],
      [ "Receiver", "classumundo_1_1_receiver.html", null ],
      [ "ResultSet< T >", "classumundo_1_1_result_set.html", null ],
      [ "Subscriber", "classumundo_1_1_subscriber.html", null ],
      [ "SubscriberConfig", "classumundo_1_1_subscriber_config.html", null ],
      [ "SubscriberImpl", "classumundo_1_1_subscriber_impl.html", null ],
      [ "Thread", "classumundo_1_1_thread.html", null ],
      [ "ZeroMQNode", "classumundo_1_1_zero_m_q_node.html", null ],
      [ "ZeroMQPublisher", "classumundo_1_1_zero_m_q_publisher.html", null ],
      [ "ZeroMQSubscriber", "classumundo_1_1_zero_m_q_subscriber.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "ResultSet< NodeStub >", "classumundo_1_1_result_set.html", [
        [ "ZeroMQNode", "classumundo_1_1_zero_m_q_node.html", null ]
      ] ],
      [ "ResultSet< PublisherStub >", "classumundo_1_1_result_set.html", [
        [ "ZeroMQSubscriber", "classumundo_1_1_zero_m_q_subscriber.html", null ]
      ] ],
      [ "Configuration", "classumundo_1_1_configuration.html", [
        [ "DiscoveryConfig", "classumundo_1_1_discovery_config.html", null ],
        [ "NodeConfig", "classumundo_1_1_node_config.html", null ],
        [ "PublisherConfig", "classumundo_1_1_publisher_config.html", null ],
        [ "SubscriberConfig", "classumundo_1_1_subscriber_config.html", null ]
      ] ],
      [ "Debug", "classumundo_1_1_debug.html", null ],
      [ "Discovery", "classumundo_1_1_discovery.html", null ],
      [ "EndPoint", "classumundo_1_1_end_point.html", [
        [ "NodeStub", "classumundo_1_1_node_stub.html", [
          [ "AvahiNodeStub", "classumundo_1_1_avahi_node_stub.html", null ],
          [ "BonjourNodeStub", "classumundo_1_1_bonjour_node_stub.html", null ],
          [ "Node", "classumundo_1_1_node.html", null ],
          [ "NodeImpl", "classumundo_1_1_node_impl.html", [
            [ "ZeroMQNode", "classumundo_1_1_zero_m_q_node.html", null ]
          ] ]
        ] ],
        [ "PublisherStub", "classumundo_1_1_publisher_stub.html", [
          [ "Publisher", "classumundo_1_1_publisher.html", null ],
          [ "PublisherImpl", "classumundo_1_1_publisher_impl.html", [
            [ "ZeroMQPublisher", "classumundo_1_1_zero_m_q_publisher.html", null ]
          ] ]
        ] ]
      ] ],
      [ "Factory", "classumundo_1_1_factory.html", null ],
      [ "Implementation", "classumundo_1_1_implementation.html", [
        [ "DiscoveryImpl", "classumundo_1_1_discovery_impl.html", [
          [ "AvahiNodeDiscovery", "classumundo_1_1_avahi_node_discovery.html", null ],
          [ "BonjourNodeDiscovery", "classumundo_1_1_bonjour_node_discovery.html", null ]
        ] ],
        [ "NodeImpl", "classumundo_1_1_node_impl.html", null ],
        [ "PublisherImpl", "classumundo_1_1_publisher_impl.html", null ],
        [ "SubscriberImpl", "classumundo_1_1_subscriber_impl.html", [
          [ "ZeroMQSubscriber", "classumundo_1_1_zero_m_q_subscriber.html", null ]
        ] ]
      ] ],
      [ "Message", "classumundo_1_1_message.html", null ],
      [ "Monitor", "classumundo_1_1_monitor.html", null ],
      [ "Mutex", "classumundo_1_1_mutex.html", null ],
      [ "NodeQuery", "classumundo_1_1_node_query.html", null ],
      [ "Receiver", "classumundo_1_1_receiver.html", null ],
      [ "ResultSet< T >", "classumundo_1_1_result_set.html", null ],
      [ "Subscriber", "classumundo_1_1_subscriber.html", null ],
      [ "Thread", "classumundo_1_1_thread.html", [
        [ "AvahiNodeDiscovery", "classumundo_1_1_avahi_node_discovery.html", null ],
        [ "BonjourNodeDiscovery", "classumundo_1_1_bonjour_node_discovery.html", null ],
        [ "SubscriberImpl", "classumundo_1_1_subscriber_impl.html", null ],
        [ "ZeroMQNode", "classumundo_1_1_zero_m_q_node.html", null ]
      ] ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "File List", "files.html", [
      [ "AvahiNodeDiscovery.cpp", "_avahi_node_discovery_8cpp.html", null ],
      [ "AvahiNodeDiscovery.h", "_avahi_node_discovery_8h.html", null ],
      [ "AvahiNodeStub.cpp", "_avahi_node_stub_8cpp.html", null ],
      [ "AvahiNodeStub.h", "_avahi_node_stub_8h.html", null ],
      [ "BonjourNodeDiscovery.cpp", "_bonjour_node_discovery_8cpp.html", null ],
      [ "BonjourNodeDiscovery.h", "_bonjour_node_discovery_8h.html", null ],
      [ "BonjourNodeStub.cpp", "_bonjour_node_stub_8cpp.html", null ],
      [ "BonjourNodeStub.h", "_bonjour_node_stub_8h.html", null ],
      [ "Common.h", "_common_8h.html", null ],
      [ "core.h", "core_8h.html", null ],
      [ "Debug.cpp", "_debug_8cpp.html", null ],
      [ "Debug.h", "_debug_8h.html", null ],
      [ "Discovery.cpp", "_discovery_8cpp.html", null ],
      [ "Discovery.h", "_discovery_8h.html", null ],
      [ "EndPoint.h", "_end_point_8h.html", null ],
      [ "Factory.cpp", "_factory_8cpp.html", null ],
      [ "Factory.h", "_factory_8h.html", null ],
      [ "Implementation.h", "_implementation_8h.html", null ],
      [ "Message.h", "_message_8h.html", null ],
      [ "Node.cpp", "_node_8cpp.html", null ],
      [ "Node.h", "_node_8h.html", null ],
      [ "NodeQuery.cpp", "_node_query_8cpp.html", null ],
      [ "NodeQuery.h", "_node_query_8h.html", null ],
      [ "NodeStub.cpp", "_node_stub_8cpp.html", null ],
      [ "NodeStub.h", "_node_stub_8h.html", null ],
      [ "portability.cpp", "portability_8cpp.html", null ],
      [ "portability.h", "portability_8h.html", null ],
      [ "Publisher.cpp", "_publisher_8cpp.html", null ],
      [ "Publisher.h", "_publisher_8h.html", null ],
      [ "ResultSet.h", "_result_set_8h.html", null ],
      [ "Subscriber.cpp", "_subscriber_8cpp.html", null ],
      [ "Subscriber.h", "_subscriber_8h.html", null ],
      [ "Thread.cpp", "_thread_8cpp.html", null ],
      [ "Thread.h", "_thread_8h.html", null ],
      [ "ZeroMQNode.cpp", "_zero_m_q_node_8cpp.html", null ],
      [ "ZeroMQNode.h", "_zero_m_q_node_8h.html", null ],
      [ "ZeroMQPublisher.cpp", "_zero_m_q_publisher_8cpp.html", null ],
      [ "ZeroMQPublisher.h", "_zero_m_q_publisher_8h.html", null ],
      [ "ZeroMQSubscriber.cpp", "_zero_m_q_subscriber_8cpp.html", null ],
      [ "ZeroMQSubscriber.h", "_zero_m_q_subscriber_8h.html", null ]
    ] ],
    [ "Directories", "dirs.html", [
      [ "src", "dir_76c32830c9f75aaeffbaef1924b15a77.html", [
        [ "umundo", "dir_940dc9d253395fea12f989f6b97946ca.html", [
          [ "common", "dir_8552584a86c7ece684628a820aeedfa2.html", null ],
          [ "connection", "dir_ab65571da479d2e94e9882026501018b.html", [
            [ "zeromq", "dir_6ad2f5869e203f88011b504e60581824.html", null ]
          ] ],
          [ "discovery", "dir_0b583a2f22496c8e89ea0ce6dc52c5a1.html", [
            [ "avahi", "dir_bf6752b99777d9d01cdf15d329b6b6fb.html", null ],
            [ "bonjour", "dir_b285c34815ee9badf84883d9ef51db1f.html", null ]
          ] ],
          [ "thread", "dir_0c5eee50d5b346d2bf822aef72d230fc.html", null ]
        ] ]
      ] ]
    ] ],
    [ "File Members", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

