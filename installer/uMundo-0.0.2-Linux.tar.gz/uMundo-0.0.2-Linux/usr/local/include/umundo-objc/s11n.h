#ifndef S11N_H_ZF0OOKPO
#define S11N_H_ZF0OOKPO

#include "umundo-objc/s11n/UMTypedPublisher.h"
#include "umundo-objc/s11n/UMTypedSubscriber.h"

#endif /* end of include guard: S11N_H_ZF0OOKPO */
